(function () {
  try {
    var fb = window.__fb;
    if (!fb || window.__fbInit) return;
    window.__fbInit = true;
    var h = (location.hostname || '').toLowerCase();
    if (!h || !fb.on(h)) return;
    var parse = JSON.parse;

    function ready(f) {
      if (document.documentElement) f();
      else new MutationObserver(function (m, o) { if (document.documentElement) { o.disconnect(); f(); } })
        .observe(document, { childList: true });
    }

    // ---- 1. Filtros cosméticos (EasyList/uBlock) ----
    var RULE = '{display:none!important}';
    function hide(list) {
      if (!list.length) return;
      var sh = null, st = null;
      try { sh = new CSSStyleSheet(); document.adoptedStyleSheets = document.adoptedStyleSheets.concat([sh]); }
      catch (e) { sh = null; }
      function ins(t) {
        try {
          if (sh) sh.insertRule(t, sh.cssRules.length); else st.sheet.insertRule(t, st.sheet.cssRules.length);
          return true;
        } catch (e) { return false; }
      }
      function go() {
        if (!sh) { st = document.createElement('style'); (document.head || document.documentElement).appendChild(st); }
        for (var i = 0; i < list.length; i += 50) {
          var chunk = list.slice(i, i + 50);
          if (!ins(chunk.join(',') + RULE)) chunk.forEach(function (s) { ins(s + RULE); });
        }
      }
      if (sh) go(); else ready(go);
    }
    var sels = [];
    try { sels = parse(fb.sel(h)); } catch (e) {}
    hide(sels);

    // ---- 2. Modo foco ----
    if (fb.focus()) {
      var FOCUS = 'header,footer,aside,nav,iframe,[class*=sidebar],[id*=sidebar],[class*=comment],[id*=comment],' +
        '[class*=related],[class*=newsletter],[class*=cookie],[class*=consent],[class*=popup],[class*=modal]' +
        '{display:none!important}body{max-width:720px!important;margin:0 auto!important;font-size:18px!important;' +
        'line-height:1.7!important;padding:12px!important}video{display:none!important}';
      ready(function () {
        var s = document.createElement('style'); s.textContent = FOCUS;
        (document.head || document.documentElement).appendChild(s);
      });
    }

    // ---- 3. Stubs anti-detector de adblock ----
    try {
      window.canRunAds = true;
      window.adsbygoogle = window.adsbygoogle || [];
      window.google_ad_status = 1;
    } catch (e) {}

    // ---- 4. Pop-ups sem interação do usuário ----
    var _open = window.open;
    window.open = function () {
      try { if (navigator.userActivation && !navigator.userActivation.isActive) return null; } catch (e) {}
      return _open.apply(this, arguments);
    };

    // ---- 5. YouTube: remove anúncios do JSON do player e pula os que sobrarem ----
    if (/(^|\.)youtube\.com$/.test(h)) {
      var clean = function (o) {
        if (!o || typeof o !== 'object') return o;
        delete o.adPlacements; delete o.playerAds; delete o.adSlots;
        if (o.playerResponse) clean(o.playerResponse);
        return o;
      };
      JSON.parse = function () { return clean(parse.apply(this, arguments)); };
      try {
        var rj = Response.prototype.json;
        Response.prototype.json = function () { return rj.apply(this, arguments).then(clean); };
      } catch (e) {}
      try {
        var ip;
        Object.defineProperty(window, 'ytInitialPlayerResponse', {
          configurable: true, get: function () { return ip; }, set: function (v) { ip = clean(v); }
        });
      } catch (e) {}
      setInterval(function () {
        var p = document.querySelector('.html5-video-player.ad-showing');
        if (!p) return;
        var v = p.querySelector('video');
        if (v && isFinite(v.duration)) { v.muted = true; v.currentTime = v.duration; }
        var b = document.querySelector('.ytp-skip-ad-button,.ytp-ad-skip-button,.ytp-ad-skip-button-modern');
        if (b) b.click();
      }, 250);
    }
  } catch (e) {}
})();
