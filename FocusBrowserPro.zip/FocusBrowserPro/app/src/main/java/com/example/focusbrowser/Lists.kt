package com.example.focusbrowser

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Baixa, guarda em cache e recompila as listas de filtros. Edite ALL para trocar/adicionar listas. */
object Lists {
    class FL(val file: String, val name: String, val url: String)

    val ALL = listOf(
        FL("easylist.txt", "EasyList", "https://easylist.to/easylist/easylist.txt"),
        FL("easyprivacy.txt", "EasyPrivacy", "https://easylist.to/easylist/easyprivacy.txt"),
        FL("ublock-filters.txt", "uBlock filters", "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/filters.txt"),
        FL("ublock-privacy.txt", "uBlock privacy", "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/privacy.txt"),
        FL("ublock-badware.txt", "uBlock badware", "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/badware.txt"),
        FL("adguard-base.txt", "AdGuard Base", "https://filters.adtidy.org/extension/ublock/filters/2.txt"),
        FL("easylist-pt.txt", "EasyList Português", "https://easylist-downloads.adblockplus.org/easylistportuguese.txt")
    )

    private val pool = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    fun dir(c: Context) = File(c.filesDir, "filters").apply { mkdirs() }

    fun rebuild(c: Context, done: ((FilterEngine) -> Unit)? = null) {
        pool.execute {
            val e = FilterEngine()
            try { c.assets.open("builtin.txt").bufferedReader().useLines { e.load(it) } } catch (_: Exception) {}
            dir(c).listFiles { f -> f.name.endsWith(".txt") }?.sortedBy { it.name }?.forEach { f ->
                try { f.bufferedReader().useLines { e.load(it) } } catch (_: Exception) {}
            }
            FilterEngine.current = e
            done?.let { cb -> ui.post { cb(e) } }
        }
    }

    /** Baixa listas desatualizadas (>2 dias) ou todas se force=true. */
    fun update(c: Context, force: Boolean, done: (ok: Int, tried: Int) -> Unit) {
        pool.execute {
            var ok = 0; var tried = 0
            for (l in ALL) {
                val f = File(dir(c), l.file)
                if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < 2 * 24 * 3600 * 1000L) continue
                tried++
                try {
                    val con = URL(l.url).openConnection() as HttpURLConnection
                    con.connectTimeout = 15000; con.readTimeout = 40000
                    con.setRequestProperty("User-Agent", "Mozilla/5.0 FocusBrowserPro")
                    if (con.responseCode == 200) {
                        val tmp = File(f.parentFile, l.file + ".tmp")
                        con.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        if (tmp.length() > 1000) { tmp.renameTo(f); ok++ } else tmp.delete()
                    }
                    con.disconnect()
                } catch (_: Exception) {}
            }
            if (ok > 0) rebuild(c) { done(ok, tried) } else ui.post { done(ok, tried) }
        }
    }
}
