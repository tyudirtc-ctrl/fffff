package com.example.focusbrowser

import android.net.Uri
import android.webkit.WebResourceRequest

const val T_SCRIPT = 1
const val T_IMAGE = 2
const val T_STYLE = 4
const val T_SUBDOC = 8
const val T_XHR = 16
const val T_MEDIA = 32
const val T_FONT = 64
const val T_OTHER = 128

class Ctx(val url: String, val host: String, val pageHost: String, val third: Boolean, val type: Int) {
    val lower: String by lazy(LazyThreadSafetyMode.NONE) { url.lowercase() }
}

private val SLD = setOf(
    "co.uk", "org.uk", "ac.uk", "gov.uk", "com.br", "net.br", "org.br", "gov.br", "com.au", "net.au",
    "org.au", "co.jp", "co.nz", "co.za", "co.in", "com.mx", "com.ar", "com.cn", "com.tr", "com.tw",
    "com.hk", "com.sg", "co.kr"
)

fun regDomain(host: String): String {
    val p = host.split('.')
    if (p.size <= 2) return host
    val l2 = p[p.size - 2] + "." + p[p.size - 1]
    return if (l2 in SLD) p.takeLast(3).joinToString(".") else l2
}

fun isThirdParty(host: String, page: String) =
    page.isNotEmpty() && regDomain(host.lowercase()) != regDomain(page)

private val JS_EXT = setOf("js", "mjs")
private val IMG_EXT = setOf("png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "avif", "bmp")
private val FONT_EXT = setOf("woff", "woff2", "ttf", "otf", "eot")
private val MEDIA_EXT = setOf("mp4", "webm", "m3u8", "mp3", "ogg", "m4s", "ts", "mpd", "aac")

/** WebView não informa o tipo do recurso: inferimos por extensão e header Accept. */
fun detectType(r: WebResourceRequest): Int {
    val ext = (r.url.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
    val acc = r.requestHeaders["Accept"] ?: ""
    return when {
        ext in JS_EXT -> T_SCRIPT
        ext in IMG_EXT || acc.startsWith("image/") -> T_IMAGE
        ext == "css" || acc.startsWith("text/css") -> T_STYLE
        ext in FONT_EXT -> T_FONT
        ext in MEDIA_EXT -> T_MEDIA
        acc.contains("text/html") -> T_SUBDOC
        acc.contains("json") -> T_XHR
        else -> T_SCRIPT or T_XHR or T_OTHER
    }
}

object Tracking {
    private val P = Regex("^(utm_.*|fbclid|gclid|dclid|gbraid|wbraid|msclkid|mc_eid|mc_cid|igshid|yclid|_hsenc|_hsmi|mkt_tok|vero_id|oly_enc_id|oly_anon_id)$")
    fun clean(u: Uri): Uri {
        if (!u.isHierarchical) return u
        val names = u.queryParameterNames
        if (names.none { P.matches(it) }) return u
        val b = u.buildUpon().clearQuery()
        names.filter { !P.matches(it) }.forEach { n -> u.getQueryParameters(n).forEach { b.appendQueryParameter(n, it) } }
        return b.build()
    }
}

class NetRule(
    private val pattern: String, private val isRegex: Boolean, private val hostAnchor: Boolean,
    private val startAnchor: Boolean, private val endAnchor: Boolean, private val hostOnly: Boolean,
    val important: Boolean, private val thirdParty: Int, private val typeMask: Int,
    private val notTypeMask: Int, private val domInc: Array<String>?, private val domExc: Array<String>?
) {
    @Volatile private var re: Regex? = null
    @Volatile private var failed = false

    fun matches(c: Ctx): Boolean {
        if (thirdParty == 1 && !c.third) return false
        if (thirdParty == 2 && c.third) return false
        if (typeMask != 0 && (typeMask and c.type) == 0) return false
        if ((notTypeMask and c.type) != 0) return false
        if (domInc != null && !domMatch(c.pageHost, domInc)) return false
        if (domExc != null && domMatch(c.pageHost, domExc)) return false
        if (hostOnly) return true
        val r = re ?: compile() ?: return false
        return r.containsMatchIn(c.url)
    }

    private fun domMatch(h: String, l: Array<String>) = l.any { h == it || h.endsWith(".$it") }

    private fun compile(): Regex? {
        if (failed) return null
        return try { Regex(build(), RegexOption.IGNORE_CASE).also { re = it } } catch (e: Exception) { failed = true; null }
    }

    private fun build(): String {
        if (isRegex) return pattern
        val sb = StringBuilder()
        if (hostAnchor) sb.append("^[a-z][a-z0-9+.\\-]*://(?:[^/?#]*\\.)?") else if (startAnchor) sb.append('^')
        for (c in pattern) when (c) {
            '*' -> sb.append(".*")
            '^' -> sb.append("(?:[^\\w.%\\-]|$)")
            '.', '$', '+', '?', '{', '}', '(', ')', '[', ']', '\\', '|' -> sb.append('\\').append(c)
            else -> sb.append(c)
        }
        if (endAnchor) sb.append('$')
        return sb.toString()
    }
}

/**
 * Motor compatível com a sintaxe Adblock Plus / uBlock / AdGuard:
 *  - regras de rede (||dominio^, |, *, ^, /regex/, @@ exceções, $third-party, $script, $image,
 *    $domain=, $important ...) indexadas por token + índice por domínio (rápido com 100k+ regras)
 *  - regras cosméticas (##seletor, dominio##seletor, #@# exceções)
 *  - formato hosts (0.0.0.0 dominio)
 */
class FilterEngine {
    private val blockHost = HashMap<String, ArrayList<NetRule>>()
    private val allowHost = HashMap<String, ArrayList<NetRule>>()
    private val blockTok = HashMap<String, ArrayList<NetRule>>()
    private val allowTok = HashMap<String, ArrayList<NetRule>>()
    private val blockGeneric = ArrayList<NetRule>()
    private val allowGeneric = ArrayList<NetRule>()

    private val genericCss = LinkedHashSet<String>()
    private val genericExc = HashSet<String>()
    private val genericNotOn = HashMap<String, HashSet<String>>()
    private val domCss = HashMap<String, ArrayList<String>>()
    private val domExc = HashMap<String, HashSet<String>>()

    var netCount = 0; private set
    var cosCount = 0; private set

    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, String>?) = size > 64
    }

    companion object {
        @Volatile var current = FilterEngine()
        private const val MAX_GENERIC = 8000
        private val COS = Regex("^([^#\\$/|\\s]*)(#@?[?\\$%]?#)(.+)$")
        private val UNSUP = Regex(":-abp-|:has-text|:contains\\(|:xpath|:matches-|:upward|:remove\\(|:style\\(|:nth-ancestor|:min-text|:watch-attr|:others|:-js-|:if\\(|:if-not\\(")
        private val OPT_OK = Regex("^[~\\w\\-,=|.*]+$")
        private val HOST_ONLY = Regex("^[a-z0-9][a-z0-9.\\-]*\\.[a-z0-9\\-]+\\^?$")
        private val HOSTS_LINE = Regex("^(?:0\\.0\\.0\\.0|127\\.0\\.0\\.1)\\s+([a-z0-9.\\-]+)")
        private fun isTok(c: Char) = c in 'a'..'z' || c in '0'..'9' || c == '%'
    }

    fun load(lines: Sequence<String>) { for (l in lines) try { addLine(l.trim()) } catch (_: Exception) {} }

    private fun addLine(l: String) {
        if (l.isEmpty() || l[0] == '!' || l[0] == '[' || l[0] == '#' && !l.startsWith("##") && !l.startsWith("#@#")) return
        HOSTS_LINE.find(l)?.let { m ->
            val d = m.groupValues[1]
            if (d != "localhost") { blockHost.getOrPut(d) { ArrayList(1) }.add(NetRule(d, false, true, false, false, true, false, 0, 0, 0, null, null)); netCount++ }
            return
        }
        val m = COS.find(l)
        if (m != null) { addCosmetic(m.groupValues[1], m.groupValues[2], m.groupValues[3]); return }
        parseNet(l)
    }

    private fun addCosmetic(domPart: String, sep: String, body: String) {
        if (sep != "##" && sep != "#@#") return
        val sel = body.trim()
        if (sel.isEmpty() || sel.startsWith("+js(") || sel.startsWith("^") || sel.contains('{') || UNSUP.containsMatchIn(sel)) return
        val doms = if (domPart.isEmpty() || domPart == "*") emptyList() else domPart.lowercase().split(',')
        if (doms.any { it.contains('*') }) return
        val inc = doms.filter { !it.startsWith("~") }
        val exc = doms.filter { it.startsWith("~") }.map { it.substring(1) }
        if (sep == "##") {
            if (inc.isEmpty()) {
                genericCss.add(sel)
                if (exc.isNotEmpty()) genericNotOn.getOrPut(sel) { HashSet() }.addAll(exc)
            } else for (d in inc) domCss.getOrPut(d) { ArrayList(2) }.add(sel)
        } else {
            if (inc.isEmpty()) genericExc.add(sel) else for (d in inc) domExc.getOrPut(d) { HashSet() }.add(sel)
        }
        cosCount++
    }

    private fun typeBit(n: String) = when (n) {
        "script" -> T_SCRIPT; "image" -> T_IMAGE; "stylesheet", "css" -> T_STYLE
        "subdocument", "frame" -> T_SUBDOC; "xmlhttprequest", "xhr" -> T_XHR
        "media" -> T_MEDIA; "font" -> T_FONT; "other", "object", "ping", "beacon" -> T_OTHER
        else -> 0
    }

    private fun parseNet(line: String) {
        var l = line
        var exception = false
        if (l.startsWith("@@")) { exception = true; l = l.substring(2) }
        var opts = ""
        val di = l.lastIndexOf('$')
        if (di >= 0) {
            val cand = l.substring(di + 1)
            if (OPT_OK.matches(cand)) { opts = cand; l = l.substring(0, di) }
        }
        var third = 0; var tm = 0; var ntm = 0; var imp = false
        var inc: ArrayList<String>? = null
        var exc: ArrayList<String>? = null
        if (opts.isNotEmpty()) for (o in opts.split(',')) {
            val neg = o.startsWith("~")
            val o2 = o.removePrefix("~")
            val name = o2.substringBefore('=').lowercase()
            val value = o2.substringAfter('=', "")
            val bit = typeBit(name)
            if (bit != 0) { if (neg) ntm = ntm or bit else tm = tm or bit; continue }
            when (name) {
                "third-party", "3p" -> third = if (neg) 2 else 1
                "first-party", "1p" -> third = if (neg) 1 else 2
                "important" -> imp = true
                "match-case", "all" -> {}
                "domain", "from" -> for (d in value.lowercase().split('|')) {
                    if (d.isEmpty() || d.contains('*') || d.contains('/')) continue
                    if (d.startsWith("~")) { if (exc == null) exc = ArrayList(); exc!!.add(d.substring(1)) }
                    else { if (inc == null) inc = ArrayList(); inc!!.add(d) }
                }
                else -> return // opção não suportada (popup, csp, redirect, removeparam...): ignora a regra inteira
            }
        }
        var p = l
        var isRegex = false
        if (p.length > 2 && p.startsWith("/") && p.endsWith("/")) {
            isRegex = true; p = p.substring(1, p.length - 1)
            if (p.length > 300) return
        }
        var ha = false; var sa = false; var ea = false
        if (!isRegex) {
            if (p.startsWith("||")) { ha = true; p = p.substring(2) } else if (p.startsWith("|")) { sa = true; p = p.substring(1) }
            if (p.endsWith("|")) { ea = true; p = p.dropLast(1) }
            p = p.lowercase()
        }
        if (p.isEmpty() || p == "*") return
        val hostOnly = ha && !isRegex && HOST_ONLY.matches(p)
        val rule = NetRule(p, isRegex, ha, sa, ea, hostOnly, imp, third, tm, ntm, inc?.toTypedArray(), exc?.toTypedArray())
        if (hostOnly) {
            (if (exception) allowHost else blockHost).getOrPut(p.trimEnd('^')) { ArrayList(2) }.add(rule)
        } else {
            val tokMap = if (exception) allowTok else blockTok
            val tok = if (isRegex) null else pickToken(p, ha, sa, ea, tokMap)
            if (tok != null) tokMap.getOrPut(tok) { ArrayList(2) }.add(rule)
            else (if (exception) allowGeneric else blockGeneric).add(rule)
        }
        netCount++
    }

    /** Escolhe o token mais raro/longo do padrão para indexar a regra. */
    private fun pickToken(p: String, ha: Boolean, sa: Boolean, ea: Boolean, map: Map<String, ArrayList<NetRule>>): String? {
        var best: String? = null; var bestSize = Int.MAX_VALUE; var bestLen = 0
        var i = 0
        while (i < p.length) {
            if (!isTok(p[i])) { i++; continue }
            var j = i
            while (j < p.length && isTok(p[j])) j++
            val leftOk = if (i == 0) (ha || sa) else p[i - 1] != '*'
            val rightOk = if (j == p.length) ea else p[j] != '*'
            if (leftOk && rightOk && j - i >= 3) {
                val t = p.substring(i, j)
                val sz = map[t]?.size ?: 0
                if (sz < bestSize || (sz == bestSize && t.length > bestLen)) { best = t; bestSize = sz; bestLen = t.length }
            }
            i = j
        }
        return best
    }

    fun shouldBlock(c: Ctx): Boolean {
        val b = find(c, blockHost, blockTok, blockGeneric) ?: return false
        if (b.important) return true
        return find(c, allowHost, allowTok, allowGeneric) == null
    }

    /** Usado para impedir redirecionamentos automáticos para domínios de anúncio. */
    fun hostBlocked(host: String): Boolean {
        var h = host.lowercase()
        while (true) {
            if (blockHost.containsKey(h)) return true
            val d = h.indexOf('.'); if (d < 0) return false
            h = h.substring(d + 1)
        }
    }

    private fun find(c: Ctx, hostMap: Map<String, ArrayList<NetRule>>, tokMap: Map<String, ArrayList<NetRule>>, generic: List<NetRule>): NetRule? {
        var h = c.host
        while (true) {
            hostMap[h]?.let { l -> for (r in l) if (r.matches(c)) return r }
            val d = h.indexOf('.'); if (d < 0) break
            h = h.substring(d + 1)
        }
        val url = c.lower
        val seen = HashSet<String>()
        var i = 0
        while (i < url.length) {
            if (!isTok(url[i])) { i++; continue }
            var j = i
            while (j < url.length && isTok(url[j])) j++
            if (j - i >= 3) {
                val t = url.substring(i, j)
                if (seen.add(t)) tokMap[t]?.let { l -> for (r in l) if (r.matches(c)) return r }
            }
            i = j
        }
        for (r in generic) if (r.matches(c)) return r
        return null
    }

    /** Lista de seletores a esconder neste host, em JSON. */
    fun cosmeticJson(host: String): String {
        synchronized(cache) { cache[host]?.let { return it } }
        val j = buildCosmetic(host)
        synchronized(cache) { cache[host] = j }
        return j
    }

    private fun buildCosmetic(host: String): String {
        val parents = ArrayList<String>()
        var h = host
        while (true) { parents.add(h); val d = h.indexOf('.'); if (d < 0) break; h = h.substring(d + 1) }
        val exc = HashSet<String>()
        parents.forEach { domExc[it]?.let(exc::addAll) }
        val out = LinkedHashSet<String>()
        parents.forEach { p -> domCss[p]?.forEach { s -> if (s !in exc) out.add(s) } }
        var n = 0
        for (s in genericCss) {
            if (n >= MAX_GENERIC) break
            if (s in genericExc || s in exc) continue
            val no = genericNotOn[s]
            if (no != null && parents.any { it in no }) continue
            out.add(s); n++
        }
        val sb = StringBuilder("[")
        var first = true
        for (s in out) {
            if (!first) sb.append(','); first = false
            sb.append('"')
            for (ch in s) when (ch) {
                '"' -> sb.append("\\\""); '\\' -> sb.append("\\\\")
                '\n', '\r', '\t' -> sb.append(' '); else -> sb.append(ch)
            }
            sb.append('"')
        }
        return sb.append(']').toString()
    }
}
