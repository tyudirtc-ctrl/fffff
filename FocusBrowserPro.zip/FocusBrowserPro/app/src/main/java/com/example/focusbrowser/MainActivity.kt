package com.example.focusbrowser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.atomic.AtomicLong

class Tab(val web: WebView) {
    @Volatile var host = ""
    @Volatile var blocked = 0
}

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var script: String
    private lateinit var holder: FrameLayout
    private lateinit var url: EditText
    private lateinit var progress: ProgressBar
    private lateinit var shield: Button
    private val tabs = ArrayList<Tab>()
    private var cur: Tab? = null
    private val main = Handler(Looper.getMainLooper())
    private val total = AtomicLong(0)
    @Volatile private var allow: Set<String> = emptySet()
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val docStart by lazy { WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) }

    private val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fb", MODE_PRIVATE)
        allow = prefs.getStringSet("allow", emptySet())!!.toSet()
        total.set(prefs.getLong("total", 0))
        script = assets.open("scripts.js").bufferedReader().readText()

        Lists.rebuild(this)
        Lists.update(this, false) { ok, _ -> if (ok > 0) toast("Filtros atualizados ($ok listas)") }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        shield = Button(this).apply { text = "🛡 0"; isAllCaps = false; setOnClickListener { toggleSite() } }
        url = EditText(this).apply {
            hint = "Pesquise ou digite o endereço"; setSingleLine(); imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
        }
        top.addView(shield)
        top.addView(url, LinearLayout.LayoutParams(0, -2, 1f))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        holder = FrameLayout(this)

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, a: (View) -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { a(it) }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        bar.addView(btn("◀") { cur?.web?.let { if (it.canGoBack()) it.goBack() } })
        bar.addView(btn("▶") { cur?.web?.let { if (it.canGoForward()) it.goForward() } })
        bar.addView(btn("⟳") { cur?.web?.reload() })
        bar.addView(btn("＋") { newTab("https://duckduckgo.com") })
        bar.addView(btn("☰") { menu(it) })

        root.addView(top, -1, -2)
        root.addView(progress, -1, 8)
        root.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar, -1, -2)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val t = cur
                when {
                    customView != null -> hideCustom()
                    t != null && t.web.canGoBack() -> t.web.goBack()
                    tabs.size > 1 && t != null -> closeTab(t)
                    else -> finish()
                }
            }
        })
        newTab(intent?.dataString ?: "https://duckduckgo.com")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.dataString?.let { newTab(it) }
    }

    override fun onPause() { super.onPause(); prefs.edit().putLong("total", total.get()).apply(); cur?.web?.onPause() }
    override fun onResume() { super.onResume(); cur?.web?.onResume() }
    override fun onDestroy() {
        if (prefs.getBoolean("incognito", false)) clearData()
        super.onDestroy()
    }

    // ---------- abas ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(start: String?) {
        val w = WebView(this)
        val t = Tab(w)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            builtInZoomControls = true
            displayZoomControls = false
            safeBrowsingEnabled = true
        }
        applySettings(w)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false)
        w.addJavascriptInterface(Bridge(), "__fb")
        if (docStart) WebViewCompat.addDocumentStartJavaScript(w, script, setOf("*"))
        w.webViewClient = client(t)
        w.webChromeClient = chrome(t)
        w.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }
        tabs.add(t)
        switchTo(t)
        start?.let { go(it) }
    }

    private fun applySettings(w: WebView) {
        val desktop = prefs.getBoolean("desktop", false)
        w.settings.userAgentString = if (desktop) DESKTOP_UA else WebSettings.getDefaultUserAgent(this)
        w.settings.useWideViewPort = desktop
        w.settings.loadWithOverviewMode = desktop
        val inc = prefs.getBoolean("incognito", false)
        w.settings.cacheMode = if (inc) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        w.settings.saveFormData = !inc
    }

    private fun switchTo(t: Tab) {
        holder.removeAllViews()
        (t.web.parent as? ViewGroup)?.removeView(t.web)
        holder.addView(t.web, FrameLayout.LayoutParams(-1, -1))
        cur = t
        url.setText(t.web.url ?: "")
        refreshShield(t)
    }

    private fun closeTab(t: Tab) {
        tabs.remove(t); holder.removeView(t.web); t.web.destroy()
        if (tabs.isEmpty()) newTab("https://duckduckgo.com") else switchTo(tabs.last())
    }

    private fun go(q: String) {
        val t = q.trim()
        val target = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(t, "UTF-8")
        }
        cur?.web?.loadUrl(target)
    }

    // ---------- escudo ----------
    private fun shieldOn(host: String) = !allow.contains(regDomain(host.lowercase()))

    private fun refreshShield(t: Tab) {
        if (t !== cur) return
        shield.text = if (shieldOn(t.host)) "🛡 ${t.blocked}" else "🛡 OFF"
    }

    private fun toggleSite() {
        val t = cur ?: return
        val d = regDomain(t.host.lowercase())
        if (d.isEmpty()) return
        val s = allow.toMutableSet()
        if (!s.remove(d)) s.add(d)
        allow = s
        prefs.edit().putStringSet("allow", s).apply()
        toast(if (s.contains(d)) "Escudo desligado em $d" else "Escudo ligado em $d")
        t.web.reload(); refreshShield(t)
    }

    inner class Bridge {
        @JavascriptInterface fun on(host: String) = shieldOn(host)
        @JavascriptInterface fun sel(host: String): String =
            if (shieldOn(host)) FilterEngine.current.cosmeticJson(host.lowercase()) else "[]"
        @JavascriptInterface fun focus() = prefs.getBoolean("focus", false)
    }

    // ---------- WebViewClient: coração do bloqueio ----------
    private fun client(t: Tab) = object : WebViewClient() {
        override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
            val u = r.url
            val host = u.host?.lowercase() ?: return null
            if (r.isForMainFrame) { t.host = host; return null }
            val s = u.scheme
            if (s != "http" && s != "https") return null
            val page = t.host
            if (!shieldOn(page)) return null
            val ctx = Ctx(u.toString(), host, page, isThirdParty(host, page), detectType(r))
            if (FilterEngine.current.shouldBlock(ctx)) {
                t.blocked++; total.incrementAndGet()
                main.post { refreshShield(t) }
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return null
        }

        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
            val u = r.url
            val s = u.scheme ?: return false
            if (s != "http" && s != "https") {
                if (r.hasGesture()) try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
            val h = u.host ?: return false
            if (!r.hasGesture() && shieldOn(t.host) && FilterEngine.current.hostBlocked(h)) return true // redirect de anúncio
            val clean = Tracking.clean(u)
            if (clean != u) { v.loadUrl(clean.toString()); return true }
            return false
        }

        override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
            t.blocked = 0
            if (t === cur) url.setText(u)
            refreshShield(t)
            if (!docStart) v.evaluateJavascript(script, null)
        }

        override fun onPageFinished(v: WebView, u: String) { refreshShield(t) }
    }

    private fun chrome(t: Tab) = object : WebChromeClient() {
        override fun onProgressChanged(v: WebView, p: Int) { if (t === cur) progress.progress = p }

        // Pop-ups: só abre aba nova se foi um clique real em link comum e o destino não é anúncio
        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
            val ht = view.hitTestResult
            val target = ht.extra
            val isLink = ht.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || ht.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            if (isUserGesture && isLink && !target.isNullOrEmpty()) {
                val h = Uri.parse(target).host
                if (h == null || !FilterEngine.current.hostBlocked(h)) { newTab(target); return false }
            }
            toast("Pop-up bloqueado")
            return false
        }

        override fun onShowCustomView(v: View, cb: CustomViewCallback) {
            if (customView != null) { cb.onCustomViewHidden(); return }
            customView = v; customCb = cb
            (window.decorView as FrameLayout).addView(v, FrameLayout.LayoutParams(-1, -1))
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        override fun onHideCustomView() { hideCustom() }
    }

    private fun hideCustom() {
        val v = customView ?: return
        (window.decorView as FrameLayout).removeView(v)
        customCb?.onCustomViewHidden()
        customView = null; customCb = null
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
    }

    private fun download(u: String, ua: String?, cd: String?, mime: String?) {
        try {
            val req = DownloadManager.Request(Uri.parse(u))
                .setMimeType(mime)
                .addRequestHeader("User-Agent", ua ?: "")
                .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(u) ?: "")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(u, cd, mime))
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Baixando…")
        } catch (e: Exception) { toast("Falha no download") }
    }

    // ---------- menu ----------
    private fun menu(anchor: View) {
        fun chk(k: String) = if (prefs.getBoolean(k, false)) " ✓" else ""
        val site = cur?.host ?: ""
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Abas (${tabs.size})")
        m.menu.add(0, 2, 0, "Fechar aba")
        m.menu.add(0, 3, 0, "Modo foco" + chk("focus"))
        m.menu.add(0, 4, 0, "Site desktop" + chk("desktop"))
        m.menu.add(0, 5, 0, "Escudo neste site: " + if (shieldOn(site)) "ON" else "OFF")
        m.menu.add(0, 6, 0, "Atualizar filtros agora")
        m.menu.add(0, 7, 0, "Minhas regras")
        m.menu.add(0, 8, 0, "Modo anônimo" + chk("incognito"))
        m.menu.add(0, 9, 0, "Limpar dados")
        m.menu.add(0, 10, 0, "Estatísticas")
        m.setOnMenuItemClickListener { i ->
            when (i.itemId) {
                1 -> tabsDialog()
                2 -> cur?.let { closeTab(it) }
                3 -> flip("focus") { tabs.forEach { it.web.reload() } }
                4 -> flip("desktop") { tabs.forEach { applySettings(it.web); it.web.reload() } }
                5 -> toggleSite()
                6 -> { toast("Baixando listas…"); Lists.update(this, true) { ok, n -> toast("Atualizadas $ok de $n") } }
                7 -> rulesDialog()
                8 -> flip("incognito") { tabs.forEach { applySettings(it.web) } }
                9 -> { clearData(); toast("Dados limpos") }
                10 -> statsDialog()
            }
            true
        }
        m.show()
    }

    private fun flip(k: String, after: () -> Unit) {
        prefs.edit().putBoolean(k, !prefs.getBoolean(k, false)).apply(); after()
        toast("$k: " + if (prefs.getBoolean(k, false)) "ON" else "OFF")
    }

    private fun tabsDialog() {
        val names = tabs.map { it.web.title?.take(40) ?: it.web.url ?: "Nova aba" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Abas").setItems(names) { _, i -> switchTo(tabs[i]) }.show()
    }

    private fun rulesDialog() {
        val f = File(Lists.dir(this), "custom.txt")
        val et = EditText(this).apply {
            setText(if (f.exists()) f.readText() else "! Uma regra por linha. Exemplos:\n||anuncio.com^\nexemplo.com##.banner\n")
            minLines = 6; gravity = Gravity.TOP
        }
        AlertDialog.Builder(this).setTitle("Minhas regras").setView(et)
            .setPositiveButton("Salvar") { _, _ -> f.writeText(et.text.toString()); Lists.rebuild(this) { toast("Regras aplicadas") } }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun statsDialog() {
        val e = FilterEngine.current
        AlertDialog.Builder(this).setTitle("Estatísticas")
            .setMessage("Regras de rede: ${e.netCount}\nRegras cosméticas: ${e.cosCount}\n" +
                "Bloqueados nesta página: ${cur?.blocked ?: 0}\nBloqueados no total: ${total.get()}")
            .setPositiveButton("OK", null).show()
    }

    private fun clearData() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        tabs.forEach { it.web.clearCache(true); it.web.clearHistory() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
